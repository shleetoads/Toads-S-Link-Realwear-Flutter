# rw_speech_recognizer_example

Demonstrates how to use the rw_speech_recognizer plugin.
