## 2.0.0

- Initial release of lepsi.city variant of this plugin

## 1.0.0

- Initial release.
